/**
 * NEXUS — Header Module
 * Handles: sticky header, mobile menu toggle, hamburger animation, dropdown
 * Version: 1.0.0
 */

'use strict';

const NexusHeader = (() => {

  // -------------------------------------------------------------------------
  // DOM references
  // -------------------------------------------------------------------------
  const header      = document.querySelector('.header');
  const hamburger   = document.querySelector('.hamburger');
  const navMobile   = document.querySelector('.nav-mobile');
  const overlay     = document.querySelector('.nav-overlay');
  const dropToggles = document.querySelectorAll('.nav-item--has-dropdown');

  // -------------------------------------------------------------------------
  // Sticky header on scroll
  // -------------------------------------------------------------------------
  const handleScroll = () => {
    if (!header) return;
    if (window.scrollY > 60) {
      header.classList.add('header--sticky');
    } else {
      header.classList.remove('header--sticky');
    }
  };

  // -------------------------------------------------------------------------
  // Mobile menu toggle
  // -------------------------------------------------------------------------
  const openMenu = () => {
    if (!hamburger || !navMobile) return;
    hamburger.classList.add('is-active');
    hamburger.setAttribute('aria-expanded', 'true');
    navMobile.classList.add('is-open');
    overlay?.classList.add('is-visible');
    document.documentElement.classList.add('no-scroll');
    document.body.classList.add('no-scroll');
  };

  const closeMenu = () => {
    if (!hamburger || !navMobile) return;
    hamburger.classList.remove('is-active');
    hamburger.setAttribute('aria-expanded', 'false');
    navMobile.classList.remove('is-open');
    overlay?.classList.remove('is-visible');
    document.documentElement.classList.remove('no-scroll');
    document.body.classList.remove('no-scroll');
  };

  const toggleMenu = () => {
    if (navMobile?.classList.contains('is-open')) {
      closeMenu();
    } else {
      openMenu();
    }
  };

  // -------------------------------------------------------------------------
  // Dropdown (desktop — keyboard + mouse)
  // -------------------------------------------------------------------------
  const initDropdowns = () => {
    dropToggles.forEach(item => {
      const link     = item.querySelector('.nav-link');
      const dropdown = item.querySelector('.dropdown');

      if (!link || !dropdown) return;

      // Mouse
      item.addEventListener('mouseenter', () => dropdown.classList.add('is-visible'));
      item.addEventListener('mouseleave', () => dropdown.classList.remove('is-visible'));

      // Keyboard
      link.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          const isOpen = dropdown.classList.contains('is-visible');
          // Close all others first
          document.querySelectorAll('.dropdown.is-visible').forEach(d => d.classList.remove('is-visible'));
          if (!isOpen) dropdown.classList.add('is-visible');
        }
        if (e.key === 'Escape') {
          dropdown.classList.remove('is-visible');
          link.focus();
        }
      });
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', (e) => {
      if (!e.target.closest('.nav-item--has-dropdown')) {
        document.querySelectorAll('.dropdown.is-visible').forEach(d => d.classList.remove('is-visible'));
      }
    });

    // Escape key closes all
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        document.querySelectorAll('.dropdown.is-visible').forEach(d => d.classList.remove('is-visible'));
        closeMenu();
      }
    });
  };

  // -------------------------------------------------------------------------
  // Close menu on resize (tablet → desktop)
  // -------------------------------------------------------------------------
  const handleResize = () => {
    if (window.innerWidth >= 1024) closeMenu();
  };

  // -------------------------------------------------------------------------
  // Init
  // -------------------------------------------------------------------------
  const init = () => {
    // Scroll listener
    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll(); // run once on load

    // Mobile menu
    hamburger?.addEventListener('click', toggleMenu);
    overlay?.addEventListener('click', closeMenu);
    overlay?.addEventListener('touchmove', (e) => {
      e.preventDefault();
    }, { passive: false });

    // Dropdowns
    initDropdowns();

    // Resize
    window.addEventListener('resize', handleResize);
  };

  return { init };

})();
