/**
 * NEXUS — Form Validation Module
 * Client-side validation for contact and newsletter forms
 * Version: 2.0.0
 */

'use strict';

const NexusForm = (() => {

  // -------------------------------------------------------------------------
  // Validators
  // -------------------------------------------------------------------------

  /** Valid e-mail pattern (RFC 5322 simplified) */
  const isValidEmail = (v) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim());

  /** Non-empty after trim */
  const isNotEmpty = (v) => v.trim().length > 0;

  /**
   * Phone: optional field.
   * Allows digits, spaces, dashes, dots, parentheses and leading +.
   * Must be between 6 and 20 characters (digits only count).
   */
  const isValidPhone = (v) => {
    if (!v.trim()) return true; // optional
    const cleaned = v.replace(/[\s\-().+]/g, '');
    return /^\d{6,15}$/.test(cleaned);
  };

  /** Name: letters, spaces, hyphens, apostrophes only (Unicode-aware) */
  const isValidName = (v) => /^[\p{L}\s'\-\.]{2,80}$/u.test(v.trim());

  // -------------------------------------------------------------------------
  // DOM helpers
  // -------------------------------------------------------------------------

  const showError = (input, message) => {
    const group = input.closest('.form-group');
    if (!group) return;
    input.classList.add('form-control--error');
    input.classList.remove('form-control--success');
    let err = group.querySelector('.form-error');
    if (!err) {
      err = document.createElement('span');
      err.className = 'form-error';
      err.setAttribute('role', 'alert');
      group.appendChild(err);
    }
    err.textContent = message;
    input.setAttribute('aria-invalid', 'true');
  };

  const clearError = (input) => {
    const group = input.closest('.form-group');
    if (!group) return;
    input.classList.remove('form-control--error');
    const err = group.querySelector('.form-error');
    if (err) err.textContent = '';
    input.setAttribute('aria-invalid', 'false');
  };

  const markSuccess = (input) => {
    clearError(input);
    if (input.value.trim()) {
      input.classList.add('form-control--success');
    }
  };

  const showFormSuccess = (form) => {
    const msg = form.querySelector('.form-success');
    if (msg) {
      msg.classList.add('is-visible');
      setTimeout(() => msg.classList.remove('is-visible'), 5000);
    }
    form.reset();
    // reset char counter
    const counter = form.querySelector('.form-char-count');
    if (counter) counter.textContent = '0 / 2000';
    // remove success state from all inputs
    form.querySelectorAll('.form-control--success').forEach(el => el.classList.remove('form-control--success'));
  };

  // -------------------------------------------------------------------------
  // Phone input: block letters in real time
  // -------------------------------------------------------------------------

  const initPhoneRestriction = (input) => {
    if (!input) return;

    input.addEventListener('keydown', (e) => {
      // Allow: backspace, delete, tab, escape, enter, arrows, home, end
      const allowed = [
        'Backspace','Delete','Tab','Escape','Enter',
        'ArrowLeft','ArrowRight','ArrowUp','ArrowDown',
        'Home','End'
      ];
      if (allowed.includes(e.key)) return;

      // Allow: +, (, ), -, space, .
      if (['+','(',')','-',' ','.'].includes(e.key)) return;

      // Allow: 0-9
      if (/^\d$/.test(e.key)) return;

      // Allow Ctrl/Cmd shortcuts (copy, paste, select all)
      if (e.ctrlKey || e.metaKey) return;

      // Block everything else (letters, special chars, etc.)
      e.preventDefault();
    });

    // Also sanitise on paste — strip non-phone characters
    input.addEventListener('paste', (e) => {
      e.preventDefault();
      const pasted = (e.clipboardData || window.clipboardData).getData('text');
      const sanitised = pasted.replace(/[^\d\s\+\(\)\-\.]/g, '');
      document.execCommand('insertText', false, sanitised);
    });
  };

  // -------------------------------------------------------------------------
  // Textarea character counter
  // -------------------------------------------------------------------------

  const initCharCounter = (textarea) => {
    if (!textarea) return;
    const max = parseInt(textarea.getAttribute('maxlength'), 10) || 2000;
    const counter = textarea.closest('.form-group')?.querySelector('.form-char-count');
    if (!counter) return;

    const update = () => {
      const len = textarea.value.length;
      counter.textContent = `${len} / ${max}`;
      counter.classList.toggle('form-char-count--warn', len >= max * 0.9);
    };

    textarea.addEventListener('input', update);
    update();
  };

  // -------------------------------------------------------------------------
  // Field-level validation (runs on blur & submit)
  // -------------------------------------------------------------------------

  const validateField = (input) => {
    const value = input.value;
    const name  = input.name;
    const type  = input.type;

    clearError(input);

    // --- Required check ---
    if (input.required && !isNotEmpty(value)) {
      showError(input, 'This field is required.');
      return false;
    }

    // --- Skip further checks if empty and not required ---
    if (!value.trim()) {
      markSuccess(input);
      return true;
    }

    // --- Name validation ---
    if (name === 'name') {
      if (!isValidName(value)) {
        showError(input, 'Please enter a valid name (letters, spaces, hyphens only).');
        return false;
      }
      if (value.trim().length < 2) {
        showError(input, 'Name must be at least 2 characters.');
        return false;
      }
    }

    // --- Email validation ---
    if (type === 'email') {
      if (!isValidEmail(value)) {
        showError(input, 'Please enter a valid email address (e.g. name@domain.com).');
        return false;
      }
    }

    // --- Phone validation ---
    if (type === 'tel' || name === 'phone') {
      if (!isValidPhone(value)) {
        showError(input, 'Please enter a valid phone number (6–15 digits). Example: +1 212 555 0100');
        return false;
      }
    }

    // --- minLength ---
    const minLen = parseInt(input.getAttribute('minlength'), 10);
    if (minLen && value.trim().length < minLen) {
      showError(input, `Please enter at least ${minLen} characters.`);
      return false;
    }

    // --- maxLength ---
    const maxLen = parseInt(input.getAttribute('maxlength'), 10);
    if (maxLen && value.length > maxLen) {
      showError(input, `Maximum ${maxLen} characters allowed.`);
      return false;
    }

    // --- Select: must not be empty ---
    if (input.tagName === 'SELECT') {
      if (!value) {
        showError(input, 'Please select a topic.');
        return false;
      }
      markSuccess(input);
      return true;
    }

    markSuccess(input);
    return true;
  };

  // Validate checkbox (consent)
  const validateCheckbox = (checkbox) => {
    if (checkbox.required && !checkbox.checked) {
      showError(checkbox, 'You must accept the Privacy Policy to proceed.');
      return false;
    }
    clearError(checkbox);
    return true;
  };

  // -------------------------------------------------------------------------
  // Contact form init
  // -------------------------------------------------------------------------

  const initContactForm = () => {
    const form = document.querySelector('#contact-form');
    if (!form) return;

    const phoneInput    = form.querySelector('#contact-phone');
    const messageInput  = form.querySelector('#contact-message');
    const consentBox    = form.querySelector('[name="consent"]');
    const allInputs     = form.querySelectorAll('.form-control');

    // Phone: block letters in real time
    initPhoneRestriction(phoneInput);

    // Textarea: live character counter
    initCharCounter(messageInput);

    // Real-time validation on blur
    allInputs.forEach(input => {
      input.addEventListener('blur', () => {
        if (input.type === 'checkbox') return;
        validateField(input);
      });

      // Re-validate on input/change if field already has an error
      input.addEventListener('input', () => {
        if (input.classList.contains('form-control--error')) {
          validateField(input);
        }
      });

      // For <select>, also listen to 'change'
      if (input.tagName === 'SELECT') {
        input.addEventListener('change', () => validateField(input));
      }
    });

    // Consent checkbox live
    if (consentBox) {
      consentBox.addEventListener('change', () => validateCheckbox(consentBox));
    }

    // Submit
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      let isValid = true;

      allInputs.forEach(input => {
        if (input.type === 'checkbox') {
          if (!validateCheckbox(input)) isValid = false;
        } else {
          if (!validateField(input)) isValid = false;
        }
      });

      if (isValid) showFormSuccess(form);
    });
  };

  // -------------------------------------------------------------------------
  // Newsletter form
  // -------------------------------------------------------------------------

  const initNewsletterForm = () => {
    const forms = document.querySelectorAll('.newsletter-form');
    if (!forms.length) return;

    forms.forEach(form => {
      const input = form.querySelector('input[type="email"]');
      const btn   = form.querySelector('button[type="submit"]');

      form.addEventListener('submit', (e) => {
        e.preventDefault();
        if (!input) return;
        if (!isValidEmail(input.value)) {
          showError(input, 'Please enter a valid email address.');
          return;
        }
        clearError(input);
        if (btn) {
          btn.textContent = 'Subscribed ✓';
          btn.disabled = true;
          setTimeout(() => {
            btn.textContent = 'Subscribe';
            btn.disabled = false;
            input.value = '';
          }, 3000);
        }
      });

      if (input) {
        input.addEventListener('blur', () => {
          if (input.value && !isValidEmail(input.value)) {
            showError(input, 'Please enter a valid email address.');
          } else {
            clearError(input);
          }
        });
      }
    });
  };

  // -------------------------------------------------------------------------
  // Init
  // -------------------------------------------------------------------------

  const init = () => {
    initContactForm();
    initNewsletterForm();
  };

  return { init };

})();
