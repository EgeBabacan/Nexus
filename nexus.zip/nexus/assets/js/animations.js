/**
 * NEXUS — Scroll Animations Module
 * Uses Intersection Observer API — zero dependencies
 * Version: 1.0.0
 */

'use strict';

const NexusAnimations = (() => {

  const SELECTOR = '[data-animate]';
  const STAGGER_SELECTOR = '[data-animate-stagger]';
  const CLASS_VISIBLE = 'is-visible';

  const options = {
    threshold: 0.1,
    rootMargin: '0px 0px -40px 0px'
  };

  const init = () => {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      // Show everything immediately
      document.querySelectorAll(SELECTOR).forEach(el => el.classList.add(CLASS_VISIBLE));
      document.querySelectorAll(STAGGER_SELECTOR).forEach(el => el.classList.add(CLASS_VISIBLE));
      return;
    }

    const observer = new IntersectionObserver((entries, obs) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add(CLASS_VISIBLE);
          obs.unobserve(entry.target);
        }
      });
    }, options);

    // Observe [data-animate] elements
    document.querySelectorAll(SELECTOR).forEach((el, i) => {
      const delay = el.dataset.delay || (i % 4) * 100;
      el.style.transitionDelay = `${delay}ms`;
      observer.observe(el);
    });

    // Observe [data-animate-stagger] containers
    document.querySelectorAll(STAGGER_SELECTOR).forEach(el => {
      observer.observe(el);
    });

    // Trigger immediately if already in viewport on load
    setTimeout(() => {
      document.querySelectorAll(`${SELECTOR}, ${STAGGER_SELECTOR}`).forEach(el => {
        const rect = el.getBoundingClientRect();
        if (rect.top < window.innerHeight && rect.bottom > 0) {
          el.classList.add(CLASS_VISIBLE);
        }
      });
    }, 100);
  };

  return { init };

})();
