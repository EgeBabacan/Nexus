/**
 * NEXUS — Counter Animation Module
 * Animates numbers when they enter viewport
 * Version: 1.0.0
 */

'use strict';

const NexusCounter = (() => {

  const SELECTOR = '[data-counter]';

  const easeOutQuad = t => t * (2 - t);

  const animateCounter = (el) => {
    const target   = parseInt(el.dataset.counter, 10);
    const duration = parseInt(el.dataset.duration || 2000, 10);
    const suffix   = el.dataset.suffix || '';
    const prefix   = el.dataset.prefix || '';
    let startTime  = null;

    const step = (timestamp) => {
      if (!startTime) startTime = timestamp;
      const elapsed  = timestamp - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const value    = Math.round(easeOutQuad(progress) * target);

      el.textContent = prefix + value.toLocaleString() + suffix;

      if (progress < 1) {
        requestAnimationFrame(step);
      }
    };

    requestAnimationFrame(step);
  };

  const init = () => {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      // Just show final values
      document.querySelectorAll(SELECTOR).forEach(el => {
        const target = el.dataset.counter;
        const suffix = el.dataset.suffix || '';
        const prefix = el.dataset.prefix || '';
        el.textContent = prefix + parseInt(target).toLocaleString() + suffix;
      });
      return;
    }

    const elements = document.querySelectorAll(SELECTOR);
    if (!elements.length) return;

    const observer = new IntersectionObserver((entries, obs) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          animateCounter(entry.target);
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.5 });

    elements.forEach(el => observer.observe(el));
  };

  return { init };

})();
