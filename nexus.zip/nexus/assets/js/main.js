/**
 * NEXUS — Main JavaScript
 * Initializes all modules on DOM ready
 * Version: 1.0.0
 */

'use strict';

document.addEventListener('DOMContentLoaded', () => {

  // Initialize header (sticky + mobile menu)
  if (typeof NexusHeader !== 'undefined') NexusHeader.init();

  // Initialize scroll animations
  if (typeof NexusAnimations !== 'undefined') NexusAnimations.init();

  // Initialize counter animation
  if (typeof NexusCounter !== 'undefined') NexusCounter.init();

  // Initialize tabs / accordion (FAQ)
  if (typeof NexusTabs !== 'undefined') NexusTabs.init();

  // Initialize form validation
  if (typeof NexusForm !== 'undefined') NexusForm.init();

  // Lazy load images (native + fallback)
  initLazyLoad();

  // Filter buttons (portfolio)
  initFilterBtns();

  // Auto-update copyright year (all pages)
  const yearEl = document.getElementById('footer-year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

});

/**
 * Lazy load fallback for older browsers
 */
function initLazyLoad() {
  if ('loading' in HTMLImageElement.prototype) return; // native support

  const images = document.querySelectorAll('img[loading="lazy"]');
  if (!images.length) return;

  const observer = new IntersectionObserver((entries, obs) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const img = entry.target;
        if (img.dataset.src) {
          img.src = img.dataset.src;
          img.removeAttribute('data-src');
        }
        obs.unobserve(img);
      }
    });
  }, { rootMargin: '200px' });

  images.forEach(img => observer.observe(img));
}

/**
 * Portfolio filter buttons — with actual show/hide and animation
 */
function initFilterBtns() {
  const filterBtns = document.querySelectorAll('.filter-btn');
  if (!filterBtns.length) return;

  filterBtns.forEach(btn => {
    btn.setAttribute('aria-pressed', btn.classList.contains('is-active') ? 'true' : 'false');

    btn.addEventListener('click', () => {
      const filter = btn.dataset.filter;

      // Update active button state
      filterBtns.forEach(b => {
        b.classList.remove('is-active');
        b.setAttribute('aria-pressed', 'false');
      });
      btn.classList.add('is-active');
      btn.setAttribute('aria-pressed', 'true');

      // Filter cards
      const cards = document.querySelectorAll('#portfolio-grid .portfolio-card');
      cards.forEach(card => {
        const match = filter === 'all' || card.dataset.category === filter;
        if (match) {
          card.style.display = '';
          // Trigger reflow for animation
          card.style.opacity = '0';
          card.style.transform = 'translateY(16px)';
          requestAnimationFrame(() => {
            requestAnimationFrame(() => {
              card.style.transition = 'opacity 0.35s ease, transform 0.35s ease';
              card.style.opacity = '1';
              card.style.transform = 'translateY(0)';
            });
          });
        } else {
          card.style.transition = 'opacity 0.2s ease';
          card.style.opacity = '0';
          setTimeout(() => { card.style.display = 'none'; }, 200);
        }
      });
    });
  });
}
