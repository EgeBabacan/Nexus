/**
 * NEXUS — Tabs & Accordion Module
 * Handles FAQ accordion and tab switching
 * Version: 1.0.0
 */

'use strict';

const NexusTabs = (() => {

  // -------------------------------------------------------------------------
  // FAQ Accordion
  // -------------------------------------------------------------------------
  const initAccordion = () => {
    const items = document.querySelectorAll('.faq-item');
    if (!items.length) return;

    items.forEach(item => {
      const question = item.querySelector('.faq-question');
      const answer   = item.querySelector('.faq-answer');

      if (!question || !answer) return;

      // Set ARIA attributes
      const answerId   = `faq-answer-${Math.random().toString(36).slice(2, 7)}`;
      answer.id        = answerId;
      question.setAttribute('aria-controls', answerId);
      question.setAttribute('aria-expanded', 'false');

      question.addEventListener('click', () => {
        const isActive = item.classList.contains('is-active');

        // Close all items
        items.forEach(i => {
          i.classList.remove('is-active');
          const a = i.querySelector('.faq-answer');
          const q = i.querySelector('.faq-question');
          if (a) a.classList.remove('is-open');
          if (q) q.setAttribute('aria-expanded', 'false');
        });

        // Open clicked item if it was closed
        if (!isActive) {
          item.classList.add('is-active');
          answer.classList.add('is-open');
          question.setAttribute('aria-expanded', 'true');
        }
      });
    });
  };

  // -------------------------------------------------------------------------
  // Tabs
  // -------------------------------------------------------------------------
  const initTabs = () => {
    const tabGroups = document.querySelectorAll('[data-tabs]');
    if (!tabGroups.length) return;

    tabGroups.forEach(group => {
      const triggers = group.querySelectorAll('[data-tab]');
      const panels   = group.querySelectorAll('[data-tab-panel]');

      triggers.forEach(trigger => {
        trigger.addEventListener('click', () => {
          const target = trigger.dataset.tab;

          triggers.forEach(t => {
            t.classList.remove('is-active');
            t.setAttribute('aria-selected', 'false');
          });
          panels.forEach(p => p.classList.remove('is-active'));

          trigger.classList.add('is-active');
          trigger.setAttribute('aria-selected', 'true');

          const panel = group.querySelector(`[data-tab-panel="${target}"]`);
          if (panel) panel.classList.add('is-active');
        });
      });
    });
  };

  // -------------------------------------------------------------------------
  // Init
  // -------------------------------------------------------------------------
  const init = () => {
    initAccordion();
    initTabs();
  };

  return { init };

})();
