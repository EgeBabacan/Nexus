# Placeholder Images

Bu klasör demo görseller için ayrılmıştır.

Önerilen boyutlar:
- hero/hero-main.jpg         → 1280×720px
- team/team-1.jpg            → 400×400px (kare)
- portfolio/project-1.jpg    → 800×600px
- blog/post-1.jpg            → 800×500px
- about/about-team.jpg       → 1200×800px

Gerçek görseller için: https://unsplash.com veya https://picsum.photos
